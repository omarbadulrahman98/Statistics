package com.sw.statistics

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import java.io.File

/** پردی نێوان HTML و ئەندرۆید: ناردنی PDF ڕاستەوخۆ بۆ وەتس ئەپ / ڤایبەر */
class Bridge(private val ctx: Context) {

    private fun uriFor(b64: String, name: String): android.net.Uri {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    }

    private fun build(uri: android.net.Uri, mime: String, pkg: String?, num: String) =
        Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            if (pkg != null) setPackage(pkg)
            // ژمارە هەبوو → چاتی ئەو کەسە ڕاستەوخۆ دەکرێتەوە
            if ((pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") && num.isNotEmpty())
                putExtra("jid", "$num@s.whatsapp.net")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    /** pkg بەتاڵ = لیستی گشتی؛ num = ژمارەی نێودەوڵەتی بێ + (نموونە 9647501234567) */
    @JavascriptInterface
    fun sharePdf(b64: String, name: String, pkg: String, num: String) {
        val uri = uriFor(b64, name)
        val list = when (pkg) {
            "" -> emptyList()
            "com.whatsapp" -> listOf("com.whatsapp", "com.whatsapp.w4b")
            else -> listOf(pkg)
        }
        for (p in list) {
            try { ctx.startActivity(build(uri, "application/pdf", p, num)); return }
            catch (_: ActivityNotFoundException) {}
        }
        ctx.startActivity(
            Intent.createChooser(build(uri, "application/pdf", null, ""), "ناردن")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** بۆ هەناردەی داتا (JSON) و فایلی تر — لیستی گشتی */
    @JavascriptInterface
    fun shareFile(b64: String, name: String, mime: String) {
        val uri = uriFor(b64, name)
        ctx.startActivity(
            Intent.createChooser(build(uri, mime, null, ""), "هەڵگرتن / ناردن")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
